package com.exercise.ingredientes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IngredientesApplicationTests {

	@Test
	void contextLoads() {
	}

}
